# Fortnite-External
Fortnite FZSoftware external Discord: https://discord.gg/Xs82vWMjqd
